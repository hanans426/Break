create function bit_length(text)
  returns integer
immutable
strict
parallel safe
cost 1
language sql
as $$
select pg_catalog.octet_length($1) * 8
$$;

comment on function bit_length(text)
is 'length in bits';

alter function bit_length(text)
  owner to postgres;

